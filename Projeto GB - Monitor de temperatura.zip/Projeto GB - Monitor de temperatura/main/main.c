#include <stdio.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"
#include "esp_log.h"
#include "rom/ets_sys.h"

#define DHT11_PIN   4
#define TAG         "DHT11"

typedef struct {
    float temperature;
    float humidity;
} dht11_data_t;

static int dht11_read(dht11_data_t *out)
{
    uint8_t data[5] = {0};
    int timeout;

    gpio_set_direction(DHT11_PIN, GPIO_MODE_OUTPUT);
    gpio_set_level(DHT11_PIN, 0);
    vTaskDelay(20 / portTICK_PERIOD_MS);
    gpio_set_level(DHT11_PIN, 1);
    ets_delay_us(30);
    gpio_set_direction(DHT11_PIN, GPIO_MODE_INPUT);

    timeout = 0;
    while (gpio_get_level(DHT11_PIN) == 1) {
        if (++timeout > 100) return -1;
        ets_delay_us(1);
    }
    timeout = 0;
    while (gpio_get_level(DHT11_PIN) == 0) {
        if (++timeout > 100) return -1;
        ets_delay_us(1);
    }
    timeout = 0;
    while (gpio_get_level(DHT11_PIN) == 1) {
        if (++timeout > 100) return -1;
        ets_delay_us(1);
    }

    for (int i = 0; i < 40; i++) {
        timeout = 0;
        while (gpio_get_level(DHT11_PIN) == 0) {
            if (++timeout > 60) return -1;
            ets_delay_us(1);
        }
        ets_delay_us(35);
        if (gpio_get_level(DHT11_PIN) == 1) {
            data[i / 8] |= (1 << (7 - (i % 8)));
        }
        timeout = 0;
        while (gpio_get_level(DHT11_PIN) == 1) {
            if (++timeout > 80) return -1;
            ets_delay_us(1);
        }
    }

    if (data[4] != ((data[0] + data[1] + data[2] + data[3]) & 0xFF)) {
        return -2;
    }

    out->humidity    = (float)data[0] + data[1] * 0.1f;
    out->temperature = (float)data[2] + data[3] * 0.1f;
    return 0;
}

void app_main(void)
{
    gpio_set_pull_mode(DHT11_PIN, GPIO_PULLUP_ONLY);

    ESP_LOGI(TAG, "Monitor de Temperatura iniciado — DHT11 no GPIO%d", DHT11_PIN);

    while (1) {
        dht11_data_t reading;
        int ret = dht11_read(&reading);

        if (ret == 0) {
            ESP_LOGI(TAG, "Temperatura: %.1f C  |  Umidade: %.1f %%",
                     reading.temperature, reading.humidity);
        } else {
            ESP_LOGW(TAG, "Falha na leitura (erro %d) — tentando novamente em 3s", ret);
        }

        vTaskDelay(3000 / portTICK_PERIOD_MS);
    }
}
