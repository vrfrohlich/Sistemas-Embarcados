# Pendências — Projeto GB Monitor de Temperatura

---

## Status Atual

| Item | Status |
|------|--------|
| Estrutura do projeto ESP-IDF | ✅ Feito |
| Driver DHT11 (protocolo single-wire) | ✅ Feito |
| Leitura periódica + saída serial | ✅ Feito |
| Esquema de ligação documentado | ✅ Feito |
| Modelo do sensor confirmado (DHT11) | ✅ Confirmado |
| Montagem física do circuito | ⏳ Pendente |
| Validação no hardware real | ⏳ Pendente |
| Definir GPIO de uso (atualmente GPIO 4) | ⏳ Confirmar |
| Relatório / documentação para entrega | ⏳ Pendente |

---

## Pendências

### Hardware
- [ ] Montar o circuito físico na protoboard (ESP32 + DHT11 + resistor 4.7 kΩ)
- [ ] Confirmar qual GPIO será usado (código usa GPIO 4 — alterar `DHT11_PIN` em `main.c` se necessário)
- [ ] Verificar se a versão do ESP32 disponível é DevKit ou outra variante

### Firmware
- [ ] Gerar o `sdkconfig` com `idf.py build` (necessário na primeira compilação)
- [ ] Validar as leituras no hardware real e ajustar os timeouts do driver se necessário
- [ ] Decidir se o projeto precisa de funcionalidades além da leitura serial (ver sugestões abaixo)

### Entrega / Documentação
- [ ] Criar esquema elétrico (Fritzing, KiCad ou desenho manual)
- [ ] Redigir relatório do projeto (objetivo, metodologia, resultados, conclusão)
- [ ] Registrar evidências de funcionamento (print do monitor serial ou vídeo)

---

## Sugestões de Funcionalidades Extras

Caso o projeto precise de mais recursos para a entrega:

| Funcionalidade | Complexidade | O que adicionar |
|----------------|--------------|-----------------|
| LED de alerta por temperatura alta | Baixa | GPIO de saída + threshold no código |
| Display OLED (SSD1306) | Média | Componente I2C direto |
| Servidor HTTP via Wi-Fi | Média | `esp_wifi` + `esp_http_server` |
| Histórico de leituras em memória | Baixa | Array circular no firmware |
| Envio por MQTT | Alta | `esp_mqtt` + broker externo |

---

## Hardware Necessário

| Componente | Quantidade |
|------------|------------|
| ESP32 DevKit | 1 |
| Sensor DHT11 | 1 |
| Resistor 4.7 kΩ | 1 |
| Protoboard | 1 |
| Jumpers | ~4 |
| Cabo USB | 1 |

---

## Testes de Validação Rápida

Após gravar e abrir o monitor serial (`idf.py -p COM3 flash monitor`):

- Aproximar a mão do sensor → temperatura deve subir levemente
- Soprar vapor d'água perto → umidade deve subir
- Desconectar o DATA → deve aparecer `Falha na leitura (erro -1)`
