/* ============================================================================
 *  BIBLIOTECAS
 * ============================================================================ */

#include <stdio.h>              /* printf                                      */
#include "freertos/FreeRTOS.h"  /* Núcleo do FreeRTOS (sistema operacional)    */
#include "freertos/task.h"      /* vTaskDelay — pausa sem travar o processador */
#include "driver/gpio.h"        /* Controle dos pinos GPIO do ESP32            */
#include "esp_log.h"            /* ESP_LOGI / ESP_LOGW — mensagens no terminal */
#include "rom/ets_sys.h"        /* ets_delay_us — delay em microssegundos      */

/* ============================================================================
 *  CONFIGURAÇÃO DE PINOS E LIMITES DE ALERTA
 *  Altere apenas estas constantes se quiser mudar pinos ou thresholds.
 * ============================================================================ */

#define DHT22_PIN       2       /* GPIO do fio DATA do DHT22 (+ pull-up 10kΩ) */
#define LED_RED_PIN     4       /* GPIO do LED vermelho — alerta de limite     */
#define LED_GREEN_PIN   5       /* GPIO do LED verde   — leitura OK            */
#define BTN1_PIN        19      /* Botão 1 — silencia alerta por 30s           */
#define BTN2_PIN        21      /* Botão 2 — força leitura imediata do sensor  */

#define TEMP_LIMITE     30.0f   /* LED vermelho acende se temperatura ≥ este valor (°C) */
#define HUMI_LIMITE     80.0f   /* LED vermelho acende se umidade ≥ este valor (%)       */

/* Tempo em ms que o BTN1 silencia o alerta após ser pressionado. */
#define BTN_SILENCIA_MS 30000

static const char *TAG = "MONITOR";

/* ============================================================================
 *  ESTRUTURA DE DADOS DO SENSOR
 * ============================================================================ */
typedef struct {
    float temperature;  /* Temperatura em °C  */
    float humidity;     /* Umidade relativa %  */
} sensor_data_t;

/* ============================================================================
 *  DRIVER DHT22
 *
 *  O DHT22 (AM2302) usa o mesmo protocolo single-wire do DHT11, mas com
 *  valores de 16 bits — dois bytes por grandeza em vez de um.
 *
 *  Diferenças práticas em relação ao DHT11:
 *    - Sinal de início: LOW por 2ms (DHT11 precisava de 20ms)
 *    - Umidade  = (byte0 << 8 | byte1) / 10.0   → ex.: 0x02 0x58 = 600 → 60.0%
 *    - Temp     = ((byte2 & 0x7F) << 8 | byte3) / 10.0
 *      Se bit 7 do byte2 estiver em 1 → temperatura negativa
 *    - Pull-up recomendado: 10kΩ (DHT11 usava 4.7kΩ)
 *
 *  Retorno:  0 = OK,  -1 = timeout,  -2 = checksum inválido
 * ============================================================================ */
static int dht22_read(sensor_data_t *out)
{
    uint8_t data[5] = {0};
    int timeout;

    /* --- Sinal de início: ESP32 puxa LOW por 2ms, depois solta --- */
    gpio_set_direction(DHT22_PIN, GPIO_MODE_OUTPUT);
    gpio_set_level(DHT22_PIN, 0);
    vTaskDelay(2 / portTICK_PERIOD_MS);
    gpio_set_level(DHT22_PIN, 1);
    ets_delay_us(30);
    gpio_set_direction(DHT22_PIN, GPIO_MODE_INPUT);

    /* --- Resposta do sensor: LOW 80µs → HIGH 80µs --- */
    timeout = 0;
    while (gpio_get_level(DHT22_PIN) == 1) { if (++timeout > 100) return -1; ets_delay_us(1); }
    timeout = 0;
    while (gpio_get_level(DHT22_PIN) == 0) { if (++timeout > 100) return -1; ets_delay_us(1); }
    timeout = 0;
    while (gpio_get_level(DHT22_PIN) == 1) { if (++timeout > 100) return -1; ets_delay_us(1); }

    /* --- Leitura dos 40 bits ---
       Cada bit: LOW ~50µs + HIGH ~28µs (bit 0) ou HIGH ~70µs (bit 1).
       Amostramos em 35µs: se ainda está HIGH → bit 1, se voltou LOW → bit 0. */
    for (int i = 0; i < 40; i++) {
        timeout = 0;
        while (gpio_get_level(DHT22_PIN) == 0) { if (++timeout > 60) return -1; ets_delay_us(1); }
        ets_delay_us(35);
        if (gpio_get_level(DHT22_PIN) == 1) data[i / 8] |= (1 << (7 - (i % 8)));
        timeout = 0;
        while (gpio_get_level(DHT22_PIN) == 1) { if (++timeout > 80) return -1; ets_delay_us(1); }
    }

    /* --- Checksum: byte4 deve ser igual à soma dos 4 anteriores (8 bits) --- */
    if (data[4] != ((data[0] + data[1] + data[2] + data[3]) & 0xFF)) return -2;

    /* --- Converte os 4 bytes em valores físicos ---
       Umidade: concatena byte0 e byte1 em 16 bits, divide por 10.
       Temperatura: concatena byte2 (sem o bit de sinal) e byte3; se byte2 bit7=1, negativo. */
    out->humidity    = ((data[0] << 8) | data[1]) / 10.0f;
    uint16_t t_raw   = ((data[2] & 0x7F) << 8) | data[3];
    out->temperature = (data[2] & 0x80) ? -(t_raw / 10.0f) : (t_raw / 10.0f);

    return 0;
}

/* ============================================================================
 *  PONTO DE ENTRADA
 * ============================================================================ */
void app_main(void)
{
    /* --- Configuração dos pinos --- */

    /* DHT22: pull-up interno (o resistor externo 10kΩ já faz o trabalho principal) */
    gpio_set_pull_mode(DHT22_PIN, GPIO_PULLUP_ONLY);

    /* LEDs: saída, ambos começam apagados */
    gpio_set_direction(LED_RED_PIN,   GPIO_MODE_OUTPUT);
    gpio_set_direction(LED_GREEN_PIN, GPIO_MODE_OUTPUT);
    gpio_set_level(LED_RED_PIN,   0);
    gpio_set_level(LED_GREEN_PIN, 0);

    /* Botões: entrada com pull-up interno (HIGH=solto, LOW=pressionado) */
    gpio_set_direction(BTN1_PIN, GPIO_MODE_INPUT);
    gpio_set_direction(BTN2_PIN, GPIO_MODE_INPUT);
    gpio_set_pull_mode(BTN1_PIN, GPIO_PULLUP_ONLY);
    gpio_set_pull_mode(BTN2_PIN, GPIO_PULLUP_ONLY);

    ESP_LOGI(TAG, "Monitor iniciado — sensor:GPIO%d  LED_R:GPIO%d  LED_G:GPIO%d  BTN1:GPIO%d  BTN2:GPIO%d",
             DHT22_PIN, LED_RED_PIN, LED_GREEN_PIN, BTN1_PIN, BTN2_PIN);

    TickType_t silenciar_ate = 0;   /* até quando o alerta está silenciado pelo BTN1 */
    bool leitura_imediata    = false;
    int btn1_prev = 1, btn2_prev = 1;

    while (1) {
        TickType_t agora = xTaskGetTickCount() * portTICK_PERIOD_MS;

        /* --- BTN1: silencia o LED vermelho por 30s ---
           Útil para reconhecer um alerta sem remover a fonte de calor. */
        int btn1 = gpio_get_level(BTN1_PIN);
        if (btn1 == 0 && btn1_prev == 1) {
            silenciar_ate = agora + BTN_SILENCIA_MS;
            gpio_set_level(LED_RED_PIN, 0);
            ESP_LOGI(TAG, "Alerta silenciado por %d segundos", BTN_SILENCIA_MS / 1000);
        }
        btn1_prev = btn1;

        /* --- BTN2: força leitura imediata do sensor ---
           O loop normalmente espera 3s; pressionar este botão pula a espera. */
        int btn2 = gpio_get_level(BTN2_PIN);
        if (btn2 == 0 && btn2_prev == 1) {
            leitura_imediata = true;
            ESP_LOGI(TAG, "Leitura forcada pelo botao");
        }
        btn2_prev = btn2;

        /* --- Leitura do sensor --- */
        sensor_data_t leitura;
        int ret = dht22_read(&leitura);

        if (ret == 0) {
            /* Teleplot: apenas temperatura e umidade */
            printf(">Temperatura:%.1f\n>Umidade:%.1f\n",
                   leitura.temperature, leitura.humidity);

            /* LED verde aceso = sistema operando normalmente */
            gpio_set_level(LED_GREEN_PIN, 1);

            /* LED vermelho: acende se temperatura OU umidade passar do limite,
               desde que o alerta não esteja silenciado pelo BTN1. */
            bool em_alerta  = (leitura.temperature >= TEMP_LIMITE)
                           || (leitura.humidity    >= HUMI_LIMITE);
            bool silenciado = (agora < silenciar_ate);

            gpio_set_level(LED_RED_PIN, (em_alerta && !silenciado) ? 1 : 0);

            if (em_alerta && !silenciado) {
                ESP_LOGW(TAG, "ALERTA — Temp: %.1f C  Umidade: %.1f %%",
                         leitura.temperature, leitura.humidity);
            }
        } else {
            /* Falha na leitura: apaga o LED verde para indicar problema */
            gpio_set_level(LED_GREEN_PIN, 0);
            ESP_LOGW(TAG, "Falha na leitura (erro %d)", ret);
        }

        leitura_imediata = false;

        /* Aguarda 3s, mas verifica os botões a cada 50ms para não perder pressões */
        for (int i = 0; i < 60 && !leitura_imediata; i++) {
            vTaskDelay(pdMS_TO_TICKS(50));

            btn1 = gpio_get_level(BTN1_PIN);
            if (btn1 == 0 && btn1_prev == 1) {
                silenciar_ate = (xTaskGetTickCount() * portTICK_PERIOD_MS) + BTN_SILENCIA_MS;
                gpio_set_level(LED_RED_PIN, 0);
                ESP_LOGI(TAG, "Alerta silenciado por %d segundos", BTN_SILENCIA_MS / 1000);
            }
            btn1_prev = btn1;

            btn2 = gpio_get_level(BTN2_PIN);
            if (btn2 == 0 && btn2_prev == 1) leitura_imediata = true;
            btn2_prev = btn2;
        }
    }
}
